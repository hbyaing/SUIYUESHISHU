Eternal Dragon: 480 cubes, 370 bones, 22 animations.
editable/: complete editable character with embedded texture.
native-json/: original Blockbench-native exports.
The game uses the final corrected JSON and texture under src/main/resources/assets/starcrowndoll/.
